################################################################################
################################################################################
 __    __   __   __   __   ______   ______   ______   ______   ______  ______  
/\ "-./  \ /\ \ /\ "-.\ \ /\  ___\ /\  ___\ /\  __ \ /\  __ \ /\  ___\/\__  _\ 
\ \ \-./\ \\ \ \\ \ \-.  \\ \  __\_\ \ \____\ \ \__< \ \ \_\ \\ \  __\\/_/\ \/ 
 \ \_\ \ \_\\ \_\\ \_\\"\_\\ \_____\\ \_____\\ \_\ \_\\ \_\ \_\\ \_\_/   \ \_\ 
  \/_/  \/_/ \/_/ \/_/ \/_/ \/_____/ \/_____/ \/_/ /_/ \/_/\/_/ \/_/      \/_/ 
                           ┳┳┓┏┓  ┳┓┏┓┏┓  ┏┓ ┓• •    
                           ┃┃┃┗┓━━┃┃┃┃┗┓  ┣ ┏┫┓╋┓┏┓┏┓
                           ┛ ┗┗┛  ┻┛┗┛┗┛  ┗┛┗┻┗┗┗┗┛┛┗

                                  by John314                                   

################################################################################
################################################################################
##                                README FILE                                 ##
################################################################################

Recomended Requirements:
-- Intel Pentium II Processor or better 
-- SoundBlaster 16 AWE card 
-- Keyboard
-- 2 Button Mouse
-- VGA Graphics Card 
-- 16 MB RAM

Minimum Requirements (Not tested):
-- Intel 486 Processor 
-- Keyboard
-- 2 Button Mouse
-- VGA Graphics Card
-- 4 MB RAM

========================================================================
:::::::: Command-line Arguments
========================================================================

Some machines or sound cards might cause the program to freeze,
if this is the case, try playing the game without sound
To play without sound: MINEC.EXE /NOSOUND

For computers with less RAM, you can specify the /LOWMEM argument.
This argument disables block textures, and only shows colors.
It also disables sound and music.
The maximum render distance is also limited.

Custom EWADs and MWADs can be loaded into the game by using the arguments:
-WAD custom.wad    Where "custom.wad" is the name of the wad to load 
-IWAD pack.wad      Where "pack.wad" is the name of the resource pack wad to load 

WADs use the Extended-WAD format and are used to store game assets

Please do not try to load different format WAD files into the game.
WAD files for MINE3D are a custom WAD file and are not related to Doom.

Full list of arguments:

Settings:
  /NOSOUND  -- Disables sound
  /NOMUSIC  -- Disables music
  /LOWMEM   -- Enables low memory usage mode 
               *Removes block textures
               *Removes GUI textures

Other:
  -WAD custom.wad -- loads a custom wad for the base game 
  -IWAD pack.wad  -- loads a custom resource wad for the game 


========================================================================
:::::::: Controls
========================================================================

Move: WASD

Toggle Textures: t

Inventory: e
Back to main menu: ESC

Jump: space
Sneak: left shift 

If there is no mouse driver found then the following keys can be used
to emulate a mouse:

j - Look left 
l - Look right
i - Look up
k - Look down
u - Left click
o - Right click

F1 - Hide GUI
F7 - Recalculate lights (slow)

========================================================================
::::::::: Demo Verison
========================================================================

For the demo release (this one) there are some additional keys.
These are for the inventory gui.

use: `-` to scroll the listed blocks up
use: `+` to scroll the listed blocks down

========================================================================
::::::::: DISCLAMER
========================================================================

This game is inherently unstable and may result in crashing, graphical
anomalies, corupted save files, loud noises, flashing images, etc.

By using this software you take full responsability of any side effects
which may occur by running this software.

By running this software you agree that the programmer (John314) is not
responsable for any damage to your computer, harddrive, floppy drive, 
hearing, eyes, cat, dog, fish, or other animals you may have.

This project has no association with Mojang Studios or its parent 
companies. 
